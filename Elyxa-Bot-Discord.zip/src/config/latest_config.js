  module.exports = {
  token:
    process.env.token || "MTQ2NzYwNzg4NjU4MTQ2NTE4MQ.GZrXCL.hX3CePt57IqJlFLqODawe3AGJclhSUFGCuydoM",   //  elyxa token 
  prefix: ".",
  color: "#353956", // #1b696b
  Mongo: "mongodb+srv://codex:codex@cdx-in-1.0idu7ol.mongodb.net/?appName=cdx-in-1",
    //"mongodb://e4ln:ElyxaMusic@eh1.ellenhost.qzz.io:2003/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.6.0",  // mongodb+srv://codex:codex@cdx-in-1.0idu7ol.mongodb.net/?appName=cdx-in-1
  ownerIDS: ["761459615408979989", ""],
  vote: false,
  image: "https://cdn.discordapp.com/attachments/1470013516256772314/1499431376452325486/k3pf56t.png?ex=69f4c5ca&is=69f3744a&hm=235d7ad05da67dcb825a7c3a522a5cbf8cdb5b33a4e02e82daf5d7e59690f4ee&",
    setupBgLink: "https://bit.ly/elyxamusic",
  invite: "https://discord.com/api/webhooks/1477553295894773780/eJcWIReOv7u2sKeNj12ibSVC_FJykwRJksJlhw42j8nQXglhEdfeuLbZi1Hsyzsyt_K9",
  inviteTwo: "https://discord.com/api/webhooks/1477553295894773780/eJcWIReOv7u2sKeNj12ibSVC_FJykwRJksJlhw42j8nQXglhEdfeuLbZi1Hsyzsyt_K9",
  inviteThree: "https://discord.com/api/webhooks/1477553295894773780/eJcWIReOv7u2sKeNj12ibSVC_FJykwRJksJlhw42j8nQXglhEdfeuLbZi1Hsyzsyt_K9",  
    ssLink: "https://dsc.gg/xitcore",
    topGg: "https://dsc.gg/xitcore",
  topgg_Api: "",

  // Add these two lines
    startupWebhook: "https://discord.com/api/webhooks/1499379253391790162/pIRXiC1eUC29ZaQ4DtmVEuz4MGhaSAH7YRmO-5BVNoVucBxCilEdiekoQic-B0atlUAM",
    shardLogWebhook: "https://discord.com/api/webhooks/1499385357395951666/Or6PLimDgAgIOdy6eslMA9YM0MzAfr0TsTo8-xT7akNpV6I0z-hTj3MEDrGp1qlNghYR",

  shardLogWebhook: "",
  noprefixLog: "https://discord.com/api/webhooks/1499378448219635732/MvXGpGqMgG2f3hQ08E5GZuS8ukLLYp6BGnPks9xh7EcXTP8rso7VuU7Qt2xLnSaGx7mI",
  cmd_log: "https://discord.com/api/webhooks/1499380434880954439/581e6f-nnMqDj37RyIGy2pz9jhNmUrkz6-PEs2x7igF-8diGz7yksrbRDzG6c0dCCpS4",
  error_log: "https://discord.com/api/webhooks/1499380574002090024/20lcjTViLhdaR4H-JyVunB1BhMaPJjiXyo4npZYtEV2YXdm1tfF0JFdT0-02TwdCx_nx",
  blacklist_log: "https://discord.com/api/webhooks/1499380719292649584/N04K9vzieVZNChKepH8toTyUWj6bU67j9q94U7xwyJSZy8VgZwJ4PuquzTDQkncGVtPF",
  join_log: "https://discord.com/api/webhooks/1499380923395739690/dK59aLYQ8_qEv7ShOlQUNSNI1Gck1kFedzoNorGiAW5OCaRgtJp1WimbgzdXT1k9F7zn",
  leave_log: "https://discord.com/api/webhooks/1499381072981659781/Thjs30KiDUxXTLjSEBEQgD5sjtpOvDZQMfRFpsyem_yRW5guptTZ3i9ZuyV6gin77w6L",
  spotiId: "85aab1d51a174aad9eed6d7989f530e6",
  spotiSecret: "b2ad05aa725e434c88776a1be8eab6c2",
  nodes: [  
 
       {
     name: 'LavaLink SSL',
     host: 'lava-v4.ajieblogs.eu.org',
     port: 443,
     password: 'https://dsc.gg/ajidevserver',
     secure: true
  },
  
    
   {
     name: 'LvaLink Non SSL',
     host: 'lavalink.jirayu.net',
     port: 13592,
     password: 'youshallnotpass',
     secure: false
  },
   
   
  ]
   
};




